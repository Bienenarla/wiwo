
public class Kalorien
{
    private int kcal;
    public Kalorien()
    {
        // Instanzvariable initialisieren
        kcal = 0;
    }
    public int beispielMethode()
    {
        // tragen Sie hier den Code ein
        return kcal;
    }
}
